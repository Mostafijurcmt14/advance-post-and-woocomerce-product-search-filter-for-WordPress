<?php
/**
 * Plugin Name: Companies Filter Searching
 * Description: Adds custom filter functionality using Vue.js in WordPress.
 * Version: 1.0.0
 * Author: Medical Resource Connections
 * Domain Path: /languages/
 * Text Domain: companies-filter
 */

if (!defined('ABSPATH')) exit();

if(!class_exists('Companies_Filter_Searching')){
	
	final class Companies_Filter_Searching{
		
		public function __construct(){
			register_activation_hook(__FILE__, array($this,'cf_activate'));
			register_deactivation_hook(__FILE__,array($this, 'cf_deactivation'));
			add_action('wp_enqueue_scripts', array($this, 'cf_enqueue_scripts'));
			add_action('plugins_loaded', array($this, 'cf_plugin_loaded'));
		}
		
		public static function init() {
			static $instance = false;

			if( !$instance ) {
				$instance = new self();
			}

			return $instance;
		}
		
		public function cf_enqueue_scripts(){
			wp_enqueue_style( 'cf-style', plugins_url('/public/css/cf-style.css', __FILE__));
			wp_enqueue_script('cf-custom-ajax', plugins_url('/public/js/cf-custom-ajax.js', __FILE__), array('jquery'), '1.0.0', true);
			wp_localize_script('cf-custom-ajax', 'ajax_params', array(
				'ajax_url' => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('ajax_nonce') 
			));
		}

		
		public function cf_activate(){
			
		}
		
		public function cf_deactivation(){
			
		}
		
		public function cf_plugin_loaded(){
			require_once plugin_dir_path( __FILE__ ) . 'includes/class-cf-custom-post-type.php';
			require_once plugin_dir_path( __FILE__ ) . 'includes/class-companies-filter.php';
			require_once plugin_dir_path( __FILE__ ) . 'includes/class-companies-acf-fields.php';
   			new Cf_Custom_Post_type();
			new Companies_Filter();
			new Companies_Acf_Fields();
		}

	}
	
}


function Companies_Filter_Searching() {
    return Companies_Filter_Searching::init();
}

$companies_filter_searching = new Companies_Filter_Searching();


 