jQuery(document).ready(function($) {
    $('#cf-select-category, #cf-select-network').on('change', function() {
        var category = $('#cf-select-category').val();
        var network = $('#cf-select-network').val();

        $.ajax({
            url: ajax_params.ajax_url,
            type: 'POST',
            data: {
                action: 'fetch_companies',
                category: category,
                network: network,
            },
            success: function(response) {
                $('#cf-post-container').html(response);
            }
        });
    });
	
	$('#company-search').keyup(function() {
        var searchValue = $(this).val();
        if(searchValue) {
            $.ajax({
                type: 'POST',
                url: ajax_params.ajax_url,
                data: { 
                    'action': 'fetch_companies', 
                    'keyword': searchValue 
                },
                success: function(response) {
                    $('#cf-post-container').html(response);
                    return false;
                }
            });
        } else {
            $.ajax({
                type: 'POST',
                url: ajax_params.ajax_url,
                data: { 
                    'action': 'fetch_companies', 
                    'keyword': searchValue 
                },
                success: function(response) {
                    $('#cf-post-container').html(response);
                }
            });
        }
    });
	
	$('.sort-letter').click(function() {
        var selectedLetter = $(this).data('letter');

        $.ajax({
            url: ajax_params.ajax_url,
            type: 'POST',
            data: {
                action: 'fetch_companies',
                letter: selectedLetter
            },
            success: function(response) {
                $('#cf-post-container').html(response);
            }
        });
    });
	
});
