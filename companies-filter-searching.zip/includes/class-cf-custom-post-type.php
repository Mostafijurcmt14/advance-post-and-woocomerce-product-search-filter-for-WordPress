<?php
class Cf_Custom_Post_type {
    
    public function __construct() {
        add_action('init', array($this, 'cf_custom_post_type'));
    }
    
    public function cf_custom_post_type() {
        register_post_type('company', array(
            'labels' => array(
                'name' => __('All Companies', 'companies-filter'),
                'singular_name' => __('Company', 'companies-filter')
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'companies'),
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => 'dashicons-filter',
            'show_in_rest' => true, // Enable REST API support
        ));

        register_taxonomy('company_category', 'company', array(
            'label' => __('Categories', 'companies-filter'),
            'rewrite' => array('slug' => 'company-category'),
            'hierarchical' => true,
            'show_in_rest' => true, // Also enable REST API support for taxonomy
        ));
		register_taxonomy('company_network', 'company', array(
            'label' => __('Networks', 'companies-filter'),
            'rewrite' => array('slug' => 'company-network'),
            'hierarchical' => true,
            'show_in_rest' => true, // Also enable REST API support for taxonomy
        ));
    }
    
}
