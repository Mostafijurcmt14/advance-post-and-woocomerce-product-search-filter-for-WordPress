<?php

class Companies_Filter {

    public function __construct() {
		add_action('wp_ajax_fetch_companies', array($this, 'fetch_companies_by_category'));
		add_action('wp_ajax_nopriv_fetch_companies', array($this, 'fetch_companies_by_category'));
		add_shortcode('companies_filter_shortcode', array($this, 'render_companies_filter'));
    }
	
	public function render_companies_filter(){
		ob_start(); 
			?>
			<div class="cf-posts-wrap">
				<div class="cf-filter-content">
					<select id="cf-select-category">
						<option value="">Select a Category</option>
						<?php
						$categories = get_terms('company_category', array('hide_empty' => false));
						foreach ($categories as $category) {
							echo sprintf('<option value="%s">%s</option>', esc_attr($category->term_id), esc_html($category->name));
						}
						?>
					</select>

					<select id="cf-select-network">
						<option value="">Select Network</option>
						<?php
						$company_network = get_terms('company_network', array('hide_empty' => false));
						foreach ($company_network as $company_network) {
							echo sprintf('<option value="%s">%s</option>', esc_attr($company_network->term_id), esc_html($company_network->name));
						}
						?>
					</select>

					<div class="companysearch">
						<input type="text" id="company-search" name="s" placeholder="Search by name or website">
					</div>
				</div>
				
				<div class="alphabetical-sorting">
					<?php foreach (range('A', 'Z') as $letter): ?>
					<button class="sort-letter" data-letter="<?php echo $letter; ?>"><?php echo $letter; ?></button>
					<?php endforeach; ?>
				</div>
				
				
				
				<?php
					$args = array(
						'post_type' => 'company',
						'post_status' => 'publish',
						'posts_per_page' => -1
					);
					$query = new wp_query($args);
				?>
				
				<div id="cf-post-container">
					
					<?php
						if ($query->have_posts()) {
							while ($query->have_posts()) {
								$query->the_post();
								echo '<div class="cf-image">';
								$permalink = get_field('cf_field_company_url');
								if (has_post_thumbnail()) {
									echo '<a href="' . esc_url($permalink) . '">';
										the_post_thumbnail('full');
									echo '</a>';
								}
								
								echo '</div>';
								
							}
						} else {
							echo 'No posts found.';
						}
						wp_reset_postdata();
					?>

				</div>
				
			</div>
			<?php
			return ob_get_clean();  
		}

	
	

	
public function fetch_companies_by_category() {
    $category = isset($_POST['category']) ? intval($_POST['category']) : '';
    $network = isset($_POST['network']) ? intval($_POST['network']) : '';
	$keyword = wp_kses_post($_POST['keyword']);
	$letter = isset($_POST['letter']) ? sanitize_text_field($_POST['letter']) : '';
	

    $args = [
        'post_type' => 'company',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'tax_query' => [],
		's' => $keyword,
		'orderby' => 'title',
        'order' => 'ASC',
    ];
	
	
	
	if($category || $network) {
		$args['tax_query'] = array(
			'relation' => 'AND',
			array(
				'taxonomy' => 'company_category',
				'field' => 'term_id',
				'terms' => $category,
				'operator' => 'AND',
			),
			array(
				'taxonomy' => 'company_network',
				'field' => 'term_id',
				'terms' => $network,
				'operator' => 'AND',
			),
		);
	}
	
	
if (!empty($letter)) {
    add_filter('posts_where', function($where) use ($letter) {
        global $wpdb;

        // Escapes the letter for safe use in SQL LIKE clause and prepares the REGEXP pattern
        $pattern = $wpdb->esc_like($letter) . '%'; // For LIKE comparison
        $regexp_pattern = '^[0-9]*' . preg_quote($letter) . '| [0-9]*' . preg_quote($letter); // For REGEXP, matches letter at start or after a space (possibly after numbers)

        // Modify the WHERE clause to use the REGEXP pattern alongside the original LIKE condition
        $where .= $wpdb->prepare(" AND (
            $wpdb->posts.post_title LIKE %s OR
            $wpdb->posts.post_title REGEXP %s
        )", $pattern, $regexp_pattern);

        return $where;
    });
}




	

    $query = new WP_Query($args);
	
	if (!empty($letter)) {
        remove_filter('posts_where', 'filter_by_first_letter');
    }

    $html = '';
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $permalink = get_field('cf_field_company_url');
            $post_date = get_the_date();

            $html .= '<div class="cf-image">';
            if (has_post_thumbnail()) {
                $html .= '<a href="' . esc_url($permalink) . '">';
                $html .= get_the_post_thumbnail(get_the_ID(), 'full');
                $html .= '</a>';
            }
            $html .= '</div>';
        }
    } else {
        $html = 'No companies found.';
    }

    wp_reset_postdata();

    echo $html;
    wp_die();
}
}

