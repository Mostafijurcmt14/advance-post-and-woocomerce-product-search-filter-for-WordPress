<?php

class Companies_Acf_Fields {

    public function __construct() {
		$this->companies_acf_fields();
    }

public function companies_acf_fields(){
	if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array(
    'key' => 'cf_fields_group', 
    'title' => 'Company URL', 
    'fields' => array(
        array(
            'key' => 'cf_field_company_url', 
            'label' => 'Company URL', 
            'name' => 'company_url',
            'type' => 'url', 
            'instructions' => '', 
            'required' => 0, 
            'conditional_logic' => 0, 
        ),
    ),
    'location' => array(
        array(
            array(
                'param' => 'post_type',
                'operator' => '==',
                'value' => 'company', 
            ),
        ),
    ),
    'menu_order' => 0,
    'position' => 'normal',
    'style' => 'default',
    'label_placement' => 'top',
    'instruction_placement' => 'label',
    'hide_on_screen' => '',
    'active' => true,
    'description' => '',
));

endif;

}
}